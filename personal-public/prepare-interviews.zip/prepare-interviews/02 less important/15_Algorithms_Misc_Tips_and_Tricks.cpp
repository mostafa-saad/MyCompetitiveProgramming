

---------------------------------------------------------Array Flatten------------------------------------------------------------
Say we have 2D array R*C, and we want to convert it to 1D array of R*C elements

	then for any (i, j) zero based: we have i rows before us, each of C elements. In current row, j elements.
	then (i, j) = i * C + j			(note j < C)

	what if we have index X in 1 D, and want to convert it to its 2D?
	we know X = i * C + j
		then X%C = (i * C % C + j % C)%C = j
			 X/C = i*C / C + j/C = i


What about X*Y*Z?

	Then (i, j, k) = i * Y * Z + j * Z + k	-> Each term * Multiplication of next dimensions

	What about Index?
		You have 2 ways: Think left or right?

	From Right?
		Index%Z = i * Y * Z + j * Z + k = 0 + 0 + k
		Index/Z = i * Y + j + 0		= Index2

		then
			Index2%Y = 0 + j
			Index2/Y = i

	From left
		Index % (Y*Z) = 0 + j*Z + k
		Index / (Y*Z) = i + 0 + 0

		and so on

	Coding wise, the processing from left and ranking (i, j, k) are similar






















-------------------------------------------------- Modulus -------------------------------------------------------------------
	 the remainder of division of one number by another
	 a % b = a - b * [a/b]		-> sometimes problem solution depends on the equation
	 7 % 3 = 3 - 3 * 2 = 1

	 Distributive Property over +, -, *
		(a+b+c)%X = (a%X + b%X + c%X)%X			REMEMBER the last %X

	What about negative a?
			postiveMode = (a%X + X)%X		-> get smallest negative, add 1 cycle, MOD again

	MOD is expensive! That is, in case a tight order problem, code TLE due to MOD!

		if(a > MOD || a < 0)	do MOD operation

		Or more efficiently, if possible
		if(a > MOD)	a -= MOD;	// given that you are sure we are far by ONLY 1 cycle
		if(a < 0)	a += MOD;




















---------------------------------------------------------Dir Arrays------------------------------------------------------------
Do you remember code that moves in maze?

	bool findEnd(int r, int c)		// Recursion State: r, c
	{
		// Try the 4 neighbor cells
		if(findEnd(r, c-1)) return true;  	// search up
		if(findEnd(r, c+1)) return true; 	// search down
		if(findEnd(r-1, c)) return true;  	// search left
		if(findEnd(r+1, c)) return true;  	// search right

		// Can't find a way for it!
		return false;
	}

What if we do 8 moves? 16 moves? The better is recording how state is changed, and save this in array
int cr[] = {0, 0, -1, 1};
int cc[] = {-1, 1, 0, 0};

In Some problems, you need to order them, e.g. Left, Up, Right, Bottom.
Exercise: How to do it for 8 directions? How array will be for knight move in a chess?

	bool findEnd(int r, int c)		// Recursion State: r, c
	{
		for(int d = 0; d < 4; ++d)
			if(findEnd(r + cr[d], c + cc[d])) return true; 	// change r, c with change in row and change in column

		// Can't find a way for it!
		return false;
	}










