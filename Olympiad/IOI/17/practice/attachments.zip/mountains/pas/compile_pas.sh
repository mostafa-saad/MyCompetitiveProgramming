#!/bin/bash

problem=mountains

fpc -XS -O2 -o$problem grader.pas
