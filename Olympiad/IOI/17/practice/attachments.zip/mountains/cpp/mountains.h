#include <vector>

int maximum_deevs(std::vector<int> y);
