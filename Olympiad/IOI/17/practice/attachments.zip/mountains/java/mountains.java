class mountains {
	public int maximum_deevs(int y[]) {
		return 1;
	}
}
