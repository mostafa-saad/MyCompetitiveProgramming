#!/bin/bash

problem=coins

fpc -XS -O2 -o$problem grader.pas
