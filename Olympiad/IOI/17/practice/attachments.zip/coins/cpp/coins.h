#include <vector>

std::vector<int> coin_flips(std::vector<int> b, int c);
int find_coin(std::vector<int> b);
