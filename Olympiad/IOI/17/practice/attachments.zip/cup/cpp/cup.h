#include <vector>

std::vector<int> find_cup();
int ask_shahrasb(int x, int y);
